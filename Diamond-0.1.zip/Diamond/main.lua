--- STEAMODDED HEADER
--- MOD_NAME: Diamond
--- MOD_ID: Diamond
--- MOD_AUTHOR: [tu_nombre]
--- MOD_DESCRIPTION: Mod de Isaac para Balatro
--- BADGE_COLOUR: 3FC7EB
--- PREFIX: diamond

----------------------------------------------
------------MOD CODE -------------------------

-- Registrar el atlas de Isaac
SMODS.Atlas {
    key = "isaac_atlas",
    path = "isaac.png",
    px = 71,
    py = 95
}

-- Registrar el atlas del D6
SMODS.Atlas {
    key = "d6_atlas",
    path = "dice_six.png",
    px = 71,
    py = 95
}

-- Crear el joker de Isaac
local isaac_joker = SMODS.Joker {
    key = "isaac",
    loc_txt = {
        name = "Isaac",
        text = {
            "{C:mult}+4{} Mult"
        }
    },
    config = {},
    rarity = 2,
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    atlas = "isaac_atlas",
    pos = {x = 0, y = 0}
}

-- Definir el cálculo del joker
function isaac_joker:calculate(card, context)
    if context.joker_main then
        return {
            mult_mod = 4,
            message = localize('k_mult'),
            colour = G.C.MULT
        }
    end
end

-- Crear el joker D6
local d6_joker = SMODS.Joker {
    key = "d6",
    loc_txt = {
        name = "D6",
        text = {
            "Al {C:attention}venderse{}, reemplaza",
            "todos los {C:attention}Comodines{}",
            "por otros {C:green}aleatorios{}"
        }
    },
    config = {},
    rarity = 3, -- Raro
    cost = 8,
    unlocked = true,
    discovered = true,
    blueprint_compat = false, -- No compatible con blueprint
    eternal_compat = true,
    atlas = "d6_atlas", -- Usando su propio atlas
    pos = {x = 0, y = 0} -- Posición en su atlas
}

-- Definir el cálculo del D6 - efecto al venderse
function d6_joker:calculate(card, context)
    -- Cuando se vende la carta
    if context.selling_card and context.card == card then
        -- Obtener todos los jokers actuales (excepto el D6 que se está vendiendo)
        local jokers_to_replace = {}
        for i = 1, #G.jokers.cards do
            if G.jokers.cards[i] ~= card then
                table.insert(jokers_to_replace, G.jokers.cards[i])
            end
        end
        
        -- Solo ejecutar si hay jokers para reemplazar
        if #jokers_to_replace > 0 then
            -- Reemplazar cada joker por uno aleatorio
            for _, joker_card in ipairs(jokers_to_replace) do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        -- Obtener un joker aleatorio
                        local eligible_jokers = {}
                        for k, v in pairs(G.P_CENTERS) do
                            if v.set == 'Joker' and v.discovered and not v.demo then
                                table.insert(eligible_jokers, k)
                            end
                        end
                        
                        if #eligible_jokers > 0 then
                            local random_joker = eligible_jokers[math.random(#eligible_jokers)]
                            
                            -- Crear la nueva carta
                            local new_card = create_card('Joker', G.jokers, nil, nil, nil, nil, random_joker)
                            new_card:add_to_deck()
                            G.jokers:emplace(new_card)
                            
                            -- Copiar edición y stickers si los tiene
                            if joker_card.edition then
                                new_card:set_edition(joker_card.edition)
                            end
                            if joker_card.ability.eternal then
                                new_card.ability.eternal = true
                            end
                            if joker_card.ability.perishable then
                                new_card.ability.perishable = joker_card.ability.perishable
                            end
                            
                            -- Remover el joker original
                            joker_card:start_dissolve()
                            
                            -- Efecto visual
                            new_card:juice_up(0.3, 0.5)
                            play_sound('timpani')
                        end
                        return true
                    end
                }))
            end
            
            -- Mensaje de confirmación
            card_eval_status_text(card, 'extra', nil, nil, nil, {
                message = "¡Rerolleado!",
                colour = G.C.MULT
            })
        end
    end
end

-- Función para agregar el D6 al inicio
local function add_starting_d6()
    -- Verificar si se seleccionó la baraja de Isaac
    if G.GAME.selected_back and G.GAME.selected_back.name == 'b_diamond_isaac_deck' then
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.1,
            func = function()
                local d6_card = create_card('Joker', G.jokers, nil, nil, nil, nil, 'j_diamond_d6')
                d6_card:add_to_deck()
                G.jokers:emplace(d6_card)
                d6_card:start_materialize()
                return true
            end
        }))
    end
end

-- Event listener para el inicio de la partida
local game_start_run_ref = Game.start_run
function Game:start_run(args)
    local ret = game_start_run_ref(self, args)
    add_starting_d6()
    return ret
end

-- Crear la baraja de Isaac (sin función apply_to_run)
local isaac_deck = SMODS.Back {
    key = "isaac_deck",
    loc_txt = {
        name = "Baraja de Isaac",
        text = {
            "Empiezas con un {C:attention}D6{}",
            "en tu inventario"
        }
    },
    atlas = "isaac_atlas",
    pos = {x = 0, y = 0},
    config = {}
}

----------------------------------------------
------------MOD CODE END----------------------